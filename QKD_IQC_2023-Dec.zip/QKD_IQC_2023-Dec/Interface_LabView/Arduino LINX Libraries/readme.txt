For information on installing libraries, see: http://www.arduino.cc/en/Guide/Libraries

Copy all of the above folders directly into your libraries depository (e.g. Documents/Arduino/libaries)
